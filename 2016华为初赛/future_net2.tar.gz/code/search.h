#ifndef _SEARCH_H
#define _SEARCH_H
#include "node.h"
#include <deque>
#include "graph.h"

using namespace std;
class Search{
public:
	Search(Graph *graph);
	~Search();
	bool A_star(int start,int end,VertexContainer vetexs);
	float A_star_h(int start,int end);
	VerNode* findVerNodeByID(int id,VertexContainer vetexs);
	void cleartable(deque<int> *table,deque<int> tempClose,VertexContainer vetexs);
	void insertOpen(int vnode,VertexContainer vetexs);
	void updateOpen(VertexContainer vetexs);
	bool search(VertexContainer vetexs,char* demand);
	void copy(deque<int> *dst,deque<int> *rsc);
	void copy(deque<EdgeNode*> *dst,deque<EdgeNode*> *rsc);
	bool isNeighborOfPrevNode(int parent,VertexContainer vetexs);
	void clearVertexFlag(VertexContainer vetexs);
	void clearVertexFullFlag(VertexContainer vetexs);
	void initDemand(char* demand);
	int getRandomID();
	void printRoute();
	void printOnePath(int start,int end);
	void floyd(int **path,int **Dist,int** Edge,int size);
	long long getCurrentTime();
	bool goToSearch(VertexContainer vetexs,char* demand);
	deque<EdgeNode*> m_edgepath;
private:
	int m_start;
	int m_end;
	Graph *m_graph;
	int** m_distance;
	int** m_path;
	deque<int> m_open;
	deque<int> m_close;
	deque<int> m_specific;
	int time_out;
};


#endif

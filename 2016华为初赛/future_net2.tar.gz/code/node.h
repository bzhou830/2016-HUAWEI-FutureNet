#ifndef _NODE_H
#define _NODE_H
#include <deque>
using namespace std;

struct VerNode;
struct EdgeNode;

typedef deque<VerNode*> VertexContainer;
typedef deque<EdgeNode*> EdgeContainer;

typedef struct VerNode{
	int m_nID;
	EdgeContainer m_edgeOut;
	EdgeContainer m_edgeIn;
	bool m_bInOpen;//flag whethere in open
	bool m_bInClose;//flag whethere in close
	//f and g
	float m_f;
	float m_g;
} VerNode;

typedef struct EdgeNode{
	int m_eID;//edge number
	int m_weight;//edge weight
	VerNode* m_pVerFrom;
	VerNode* m_pVerTo;
} EdgeNode;

#endif 

#include "search.h"
#include <iostream>
#include <time.h>
#include <sys/timeb.h>
#include <stdlib.h>
#include <string.h>
#include <malloc.h>
using namespace std;

Search::Search(Graph *graph){
	this->m_graph=graph;
	int size=graph->m_size;
	if(size<=20){
		time_out=500;//500ms/time
	}
	else if(size<70){
		time_out=700;//700ms/time
	}
	else if(size<120){
		time_out=1000;//1000ms/time
	}
	else{
		time_out=2000;//2000ms/time
	}
	m_path=(int**)malloc(sizeof(int*)*size);
	m_distance=(int**)malloc(sizeof(int*)*size);
	for(int i=0;i<size;i++){
		m_path[i]=(int*)malloc(sizeof(int)*size);
		m_distance[i]=(int*)malloc(sizeof(int)*size);
	}
	floyd(m_path,m_distance,graph->m_graph,size);
}

Search::~Search(){
	for(int i=0; i<m_graph->m_size; i++)
	{
		free(m_path[i]);
		free(m_distance[i]);
	}
	free(m_path);
	free(m_distance);
}

float Search::A_star_h(int start,int end){
	return m_distance[start][end];
}

bool Search::A_star(int start,int end,VertexContainer vetexs){
	if(start>=0&&end>=0){
		VerNode* pv1=NULL;
		VerNode* pv2=NULL;
		//EdgeNode* pe=NULL;
		int parent;
		int size;
		int child;
		pv1= vetexs[start];

		float newg=0.0;  //�µĹ��ۺ���ֵ
		float newf=0.0;

		m_open.clear();	//��տ���
		clearVertexFlag(vetexs);//��ձ�־

		m_open.push_back(start);//����ʼ����뿪��
		pv1->m_bInOpen=true;

		pv1->m_g = 0.0f;//������ʼ��Ĺ��ۺ���ֵ
		pv1->m_f = pv1->m_g+A_star_h(start, end);
		//�㷨��ʼ
		while(m_open.size()>0){
			parent = m_open[0];//�õ���ǰ�ڵ㣬�ŵ��ձ���
			m_open.pop_front();
			pv1 = findVerNodeByID(parent,vetexs);
			pv1->m_bInOpen = false;
			
			//�жϸýڵ���ձ������һ���ڵ��Ƿ���ͨ
			if(!isNeighborOfPrevNode(parent,vetexs))
			{
				//����ͨ
				pv1->m_bInClose=false;
				continue;
			}
			if(parent!=end){
				m_close.push_back(parent);
				pv1->m_bInClose = true;
			}
			if(parent==end){
				if(parent!=m_end){
					m_edgepath.pop_back();
				}
				return true;
			}
			else{
				size=pv1->m_edgeOut.size();
				for(int i=0;i<size;i++)
				{
					EdgeNode* out_edge=pv1->m_edgeOut[i];
					child=out_edge->m_pVerTo->m_nID;
					if(m_specific.size()>0&&child==m_end){
						//�ڼ��㾭���м�ڵ�ʱ�����ܾ������һ���ڵ�
						continue;
					}
					pv2=findVerNodeByID(child,vetexs);
					newg=pv1->m_g+out_edge->m_weight;
					newf=newg+A_star_h(child, end);

					if(!pv2->m_bInOpen&&!pv2->m_bInClose){
						//pv2�ڵ㲻�ڿ�����ձ�
						pv2->m_f=newf; //���½ڵ�pv2�Ĺ���ֵ
						pv2->m_g=newg;
						insertOpen(child,vetexs);
						pv2->m_bInOpen=true;
						pv2->m_bInClose=false;
					}
					else if(pv2->m_bInOpen){
						//pv2�ڵ��ڿ���
						if(newf<pv2->m_f)
						{
							pv2->m_f = newf;//���½ڵ�pv2�Ĺ���ֵ
							pv2->m_g = newg;
							updateOpen(vetexs);
						}
					}
					else if(pv2->m_bInClose){
						//ʲô������
					}
				}
			}
		}

	}
	return false;
}


VerNode* Search::findVerNodeByID(int id,VertexContainer vetexs){
	VertexContainer::iterator it;
	for(it=vetexs.begin();it!=vetexs.end();it++)
	{
		if(id==(*it)->m_nID){
			return *it;
		}
	}
	return NULL;
}

void Search::insertOpen(int vnode,VertexContainer vetexs)
{
	//��open���в����µĽڵ㣬�����չ��ۺ�����������
	int size = m_open.size();
	VerNode* pv1 = findVerNodeByID(vnode,vetexs);
	VerNode* pv2 = NULL;
	if(size>0)
	{
		int index = -1; 
		for(int i = 0; i<size; i++){
			pv2 = findVerNodeByID(m_open[i],vetexs);
			if(pv1->m_f<=pv2->m_f){
				index = i;
				break;
			}
		}
		if(index>=0){
			m_open.insert(m_open.begin()+index, vnode);
		}else{
			m_open.push_back(vnode);
		}
	}
	else{
		m_open.push_back(vnode);
	}
}

void Search::updateOpen(VertexContainer vetexs)
{
	//����OPEN���е����ݣ�ǰ����ֻ��һ�����ݱ仯
	int size = m_open.size();
	VerNode *pv1, *pv2;
	int index = -1, temp;
	for(int i = 0; i<size-1; i++){
		pv1 = findVerNodeByID(m_open[i],vetexs);
		pv2 = findVerNodeByID(m_open[i+1],vetexs);
		if(pv1->m_f>pv2->m_f){
			index = i;
			temp = m_open[i];
			m_open[i] = m_open[i+1];
			m_open[i+1] = temp;
			break;
		}
	}

	if(index>=0)
	{
		for(int i = index+1; i<size-1; i++)
		{
			pv1 = findVerNodeByID(m_open[i],vetexs);
			pv2 = findVerNodeByID(m_open[i+1],vetexs);
			if(pv1->m_f>pv2->m_f){
				temp = m_open[i];
				m_open[i] = m_open[i+1];
				m_open[i+1] = temp;
			}else{
				break;
			}
		}

		for(int i = index; i>0; i--){
			pv1 = findVerNodeByID(m_open[i],vetexs);
			pv2 = findVerNodeByID(m_open[i-1],vetexs);
			if(pv1->m_f<pv2->m_f){
				temp = m_open[i];
				m_open[i] = m_open[i-1];
				m_open[i-1] = temp;
			}else{
				break;
			}
		}
	}
}

long long Search::getCurrentTime()
{
	long long time_last;
	struct timeb t1;    
	ftime(&t1); 
	time_last =t1.time*1000+t1.millitm; 
	return time_last;
}

bool Search::search(VertexContainer vetexs,char* demand)
{
	
	long long start_time=getCurrentTime();
	long long end_time;
	VerNode* verNode=NULL;
	deque<int> tempClose;//��ʱ�ձ�
	deque<EdgeNode*> tempPath;//��ʱ����·��
	initDemand(demand);
	int start=m_start;
	//·������ǰ׼������
	m_open.clear();
	m_close.clear();

	while(m_specific.size()>0)
	{
		int random=getRandomID();
		verNode=findVerNodeByID(random,vetexs);
		if(verNode->m_bInClose){
			//�ýڵ��Ѿ�������
			continue;//����һ���ڵ����
		}
		tempClose.clear();
		copy(&tempClose,&m_close);//��ʱ����ձ�������ʧ��ʱ�ָ��ձ�
		tempPath.clear();
		copy(&tempPath,&m_edgepath);//��ʱ����·��������ʧ��ʱ�ָ�

		bool success=A_star(start,random,vetexs);
		if(success){
			//�����ɹ�
			start=random;//random�ڵ���Ϊ�µ���ʼ��
		}
		else{
			//����ʧ��
			cleartable(&m_close,tempClose,vetexs);
			copy(&m_close,&tempClose);//�ָ��ձ�������
			m_edgepath.clear();
			copy(&m_edgepath,&tempPath);//��ʱ����·��������ʧ��ʱ�ָ�
			m_specific.push_back(random);			
		}
		end_time=getCurrentTime();
		
		if(end_time-start_time>time_out)
		{
			return false;
		}
		
	}
	//���ˣ����б���Ҫ�����Ľڵ㶼��������
	bool success=A_star(start,m_end,vetexs);//�������һ��
	if(success){
		m_close.push_back(m_end);
		//cout<<"search successful..."<<endl;
		return true;
	}
	return false;
}


bool Search::goToSearch(VertexContainer vetexs,char* demand)
{
	int i=0;
	long long start=getCurrentTime();
	while(i<=1000)
	{
		//cout<<"the "<<i+1<<" times"<<endl;
		bool success=search(vetexs,demand);
		//printRoute();
		//cout<<endl;
		long long end=getCurrentTime();
		if(end-start>10*1000)
		{
			//cout<<"time out no solution"<<endl;
			return false;
		}
		if(success)return true;
		clearVertexFullFlag(vetexs);
		m_edgepath.clear();
		i++;
	}
	return false;
}

void Search::cleartable(deque<int> *table,deque<int> tempClose,VertexContainer vetexs)
{
	for(deque<int>::iterator it=table->begin();it!=table->end();it++)
	{
		VerNode* verNode=findVerNodeByID(*it,vetexs);
		verNode->m_bInClose=false;
	}
	for(deque<int>::iterator it=tempClose.begin();it!=tempClose.end();it++)
	{
		VerNode* verNode=findVerNodeByID(*it,vetexs);
		verNode->m_bInClose=true;
	}
	table->clear();
}

int Search::getRandomID()
{
	srand((unsigned)time(NULL));
	int size=m_specific.size();
	if(size==1){
		int value=m_specific.at(0);
		m_specific.erase(m_specific.begin());
		return value;
	}
	deque<int>::iterator it=m_specific.begin();
	int random=rand()%(size-1);
	int value=m_specific.at(random);
	m_specific.erase(it+random);
	return value;
}

void Search::copy(deque<int> *dst,deque<int> *rsc)
{
	deque<int>::iterator it;
	for(it=rsc->begin();it!=rsc->end();it++)
	{
		dst->push_back(*it);
	}
}

void Search::copy(deque<EdgeNode*> *dst,deque<EdgeNode*> *rsc)
{
	deque<EdgeNode*>::iterator it;
	for(it=rsc->begin();it!=rsc->end();it++)
	{
		dst->push_back(*it);
	}
}


void Search::initDemand(char* demand){
	char* p;
	char* q;
	char *line=(char*)malloc(sizeof(char)*1024);
	strcpy(line,demand);
	//char *line=demand;
	p=strtok(line,",");
	m_start=atoi(p);
	p=strtok(NULL,",");
	m_end=atoi(p);
	q=strtok(NULL,",");

	p=strtok(q,"|");
	while(p){
		int id=atoi(p);
		m_specific.push_back(id);
		p=strtok(NULL,"|");
	}
}

void Search::printRoute()
{
	deque<int>::iterator it;
	for(it=m_close.begin();it!=m_close.end();it++)
	{
		cout<<(*it)<<"--->";
	}
	cout<<endl;

	deque<EdgeNode*>::iterator it1;
	int weight=0;
	for(it1=m_edgepath.begin();it1!=m_edgepath.end();it1++)
	{
		cout<<(*it1)->m_eID<<"--->";
		weight+=(*it1)->m_weight;
	}
	cout<<"weight:"<<weight<<endl;
}


bool Search::isNeighborOfPrevNode(int parent,VertexContainer vetexs)
{
	int size=m_close.size();
	if(size==0)return true;
	int end=m_close[size-1];
	VerNode* verNode=findVerNodeByID(end,vetexs);
	EdgeContainer ec=verNode->m_edgeOut;
	for(EdgeContainer::iterator itor=ec.begin();itor!=ec.end();itor++)
	{
		VerNode* node=(*itor)->m_pVerTo;
		if(node->m_nID==parent)
		{
			m_edgepath.push_back(*itor);
			return true;
		}
	}
	return false;
}

void Search::clearVertexFlag(VertexContainer vetexs)
{
	int size = vetexs.size();
	VerNode* pv = NULL;
	for(int i = 0; i<size; i++){
		pv=vetexs[i];
		pv->m_bInOpen = false;
		//pv->m_bInClose=false;
		pv->m_f = 0.0f;
		pv->m_g = 0.0f;
	}
}

void Search::clearVertexFullFlag(VertexContainer vetexs)
{
	int size = vetexs.size();
	VerNode* pv = NULL;
	for(int i = 0; i<size; i++){
		pv=vetexs[i];
		pv->m_bInOpen = false;
		pv->m_bInClose=false;
		pv->m_f = 0.0f;
		pv->m_g = 0.0f;
	}
	m_close.clear();
	m_open.clear();
}

void Search::floyd(int **path,int **Dist,int** Edge,int size)
{
	int i,j,k,v,w;
	for(i=0;i<size;i++)
	{
		for(j=0;j<size;j++)
		{
			Dist[i][j]=Edge[i][j];
			path[i][j]=j;
		}		
	}
	for(k=0;k<size;k++)
	{
		for(v=0;v<size;v++)
		{
			for(w=0;w<size;w++)
			{
				if(Dist[v][w]>Dist[v][k]+Dist[k][w])
				{
					Dist[v][w]=Dist[v][k]+Dist[k][w];
					path[v][w]=path[v][k];
				}
			}
		}
	}
}

void Search::printOnePath(int start,int end)
{
	int k;
	k=m_path[start][end];
	printf("V%d",start);
	while(k!=end)
	{
		printf("-->V%d",k);
		k=m_path[k][end];
	}
	printf("-->V%d  %d\n",end,m_distance[start][end]);
}



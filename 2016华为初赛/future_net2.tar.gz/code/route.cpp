#include "route.h"
#include <stdio.h>
#include "graph.h"
#include "search.h"
#include "lib_record.h"
#include<iostream>
using namespace std;
void search_route(char *topo[5000], int edge_num, char *demand)
{
	   
	Graph *graph=new Graph;
	graph->initGraph(topo,edge_num);
	graph->initGraphArray();
	Search *search=new Search(graph);
	bool success=search->goToSearch(graph->m_vertexs,demand);
	if(success){
		int size=search->m_edgepath.size();
		unsigned short result[size];
		for(int i=0;i<size;i++)
		{
			result[i]=search->m_edgepath[i]->m_eID;
			record_result(result[i]);
		}
	}
}

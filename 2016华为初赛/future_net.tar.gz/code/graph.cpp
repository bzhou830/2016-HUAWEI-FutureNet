#include<iostream>
#include<set>
#include<map>
#include<string.h>
#include<stdlib.h>
#include<list>
#include<deque>
#include "graph.h"
#include "node.h"
#include<malloc.h>
using namespace std;
Graph::Graph()
{
	
}
Graph::~Graph()
{
	for(int i=0; i<m_size; i++)
	{
		free(m_graph[i]);
	}
	free(m_graph);
}
void Graph::initGraph(char *topo[5000],int edge_num)
{
	set<int> vertexIDs;
	map<int,list<int> > outedges; //key:vertexID value:outedges
	map<int,list<int> > inedges; //key:vertexID value:inedges
	list<int> startIDs;
	list<int> endIDs;
	VerNode *pv;
	for(int i=0;i<edge_num;i++){
		char* p;
		char *line=(char*)malloc(sizeof(char)*100);
		strcpy(line,topo[i]);
		//char *line=topo[i];
		p=strtok(line,",");
		int edgeID=atoi(p);

		p=strtok(NULL,",");
		int vertexID_S=atoi(p);
		startIDs.push_back(vertexID_S);
		vertexIDs.insert(vertexID_S);

		p=strtok(NULL,",");
		int vertexID_E=atoi(p);
		endIDs.push_back(vertexID_E);
		vertexIDs.insert(vertexID_E);

		p=strtok(NULL,",");
		int cost=atoi(p);
	
		EdgeNode* pe=new EdgeNode;
		pe->m_eID=edgeID;
		pe->m_weight=cost;
		m_edges.push_back(pe);
		free(line);
	}
	//����
	for(list<int>::iterator it=startIDs.begin();it!=startIDs.end();++it)
	{
		int id=(*it);
		list<int> tempList;
		for(int i=0;i<edge_num;i++)
		{
			char* p;
			char *line=(char*)malloc(sizeof(char)*100);
			strcpy(line,topo[i]);

			p=strtok(line,",");
			int edgeID=atoi(p);

			p=strtok(NULL,",");
			int vertexID_S=atoi(p);
			if(vertexID_S==id)
			{
				tempList.push_back(edgeID);					
			}
			free(line);
		}
		outedges.insert(pair<int,list<int> >(id,tempList));
	}
	//���
	for(list<int>::iterator it=endIDs.begin();it!=endIDs.end();++it)
	{
		int id=(*it);
		list<int> tempList;
		for(int i=0;i<edge_num;i++)
		{
			char* p;
			char *line=(char*)malloc(sizeof(char)*100);
			strcpy(line,topo[i]);

			p=strtok(line,",");
			int edgeID=atoi(p);

			p=strtok(NULL,",");
			p=strtok(NULL,",");
			int vertexID_E=atoi(p);
			if(vertexID_E==id)
			{
				tempList.push_back(edgeID);		
			}
			free(line);
		}
		inedges.insert(pair<int,list<int> >(id,tempList));
	}

	for(set<int>::iterator it=vertexIDs.begin();it!=vertexIDs.end();++it)
	{
		pv=new VerNode;
		pv->m_nID=(*it);
		pv->m_bInClose=false;
		pv->m_bInOpen=false;
		pv->m_f=0;
		pv->m_g=0;
		map<int,list<int> >::iterator iter_out=outedges.find(*it);
		if(iter_out!=outedges.end()){
			list<int> out=iter_out->second;	
			EdgeContainer ec;
			for(list<int>::iterator i=out.begin();i!=out.end();++i)
			{	
				EdgeNode* e=findEdgeByID(*i);
				e->m_pVerFrom=pv;
				ec.push_back(e);
			}
			pv->m_edgeOut=ec;
		}
		map<int,list<int> >::iterator iter_in=inedges.find(*it);
		if(iter_in!=inedges.end()){
			list<int> in=iter_in->second;	
			EdgeContainer ec;
			for(list<int>::iterator i=in.begin();i!=in.end();++i)
			{	
				EdgeNode* e=findEdgeByID(*i);
				e->m_pVerTo=pv;
				ec.push_back(e);
			}
			pv->m_edgeIn=ec;
		}
		m_vertexs.push_back(pv);	
	}
	//cout<<m_vertexs.size()<<endl;
}

EdgeNode* Graph::findEdgeByID(int id){
	for(deque<EdgeNode*>::iterator it=m_edges.begin();it!=m_edges.end();++it)
	{
		EdgeNode* edge=(*it);
		if(id==edge->m_eID){
			return edge;
		}
	}
	return NULL;
}


void Graph::initGraphArray()
{
	int size=m_vertexs.size();
	m_size=size;
	m_graph=(int**)malloc(sizeof(int*)*size);
	for(int i=0;i<size;i++){
		m_graph[i]=(int*)malloc(sizeof(int)*size);
	}

	for(int i=0;i<size;i++){
		for(int j=0;j<size;j++)
		{
			m_graph[i][j]=getWeight(i,j);
		}
	}
}

int Graph::getWeight(int start,int end)
{
	if(start==end)return 0;
	VerNode* node=m_vertexs[start];
	EdgeContainer ec=node->m_edgeOut;
	for(EdgeContainer::iterator it=ec.begin();it!=ec.end();it++)
	{
		EdgeNode* edge=*it;
		if(edge->m_pVerTo->m_nID==end){
			return edge->m_weight;
		}
	}
	return 65535;
}



#ifndef _GRAPH_H
#define _GRAPH_H
#include<stdio.h>
#include<map>
#include "node.h"
#define nMax 20
class Graph{

public:
	Graph();
	~Graph();
	void initGraph(char *topo[5000],int edge_num);
	EdgeNode* findEdgeByID(int id);
	void initGraphArray();
	int getWeight(int start,int end);
	
public:
	VertexContainer m_vertexs;
	EdgeContainer m_edges;
	int** m_graph;
	int m_size;
};

#endif

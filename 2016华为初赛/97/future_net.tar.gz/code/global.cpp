#include <cstdlib>
#include "global.h"
#include <vector>

//std::vector<sEdge> Edges;



